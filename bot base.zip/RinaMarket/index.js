const Discord = require("discord.js");

const { type } = require("os");

const Client = new Discord.Client;

const prefix = "!";

Client.on("ready", () => {
    console.log("Bot Prêt !");
    setTimeout(() => {
    Client.user.setActivity("[ ! ]", {type: 'COMPETING'} );
    }, 100)
});

Client.on("message", message => {
    if(message.author.bot) return;

        //!c
if(message.content == prefix + "ping"){
    message.channel.send("**Pong**");
    }

});
    


Client.login("tontoken");